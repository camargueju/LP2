﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstbxEntrada.Items.Clear();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[2, 4];
            int totalGeral = 0; //todos produtos em todas semanas do mês
            int[] totalProd = new int[2];

            lstbxEntrada.Items.Clear();

            string entrada = "";
            bool valido = false;

            //entrada de valores
            for (int prod = 0; prod < 2; prod++)//linhas
            {
                for (int seman = 0; seman < 4; seman++)//colunas
                {
                    do
                    {
                        entrada = Interaction.InputBox("Digite os valores correspondentes aos produtos...\n");


                    } while (!valido);

                  //  string input = Interaction.InputBox($"Total Entradas do produto: {prod + 1}, Semana: {seman + 1}.");

                    if (int.TryParse(input, out int valor) && valor >= 0)
                    {
                        matriz[prod, seman] = valor;
                        valido = true;
                    }
                    else
                    {
                        MessageBox.Show("valor invalido. digite número inteiros maiores ou iguais a zero.");

                    }
                }
            }

            //calculando total por produto
            for (int prod = 0; prod < 2; prod++)
            {
                totalProd[prod] = 0;

                for (int seman = 0; seman < 4; seman++)
                {
                    totalProd[prod] += matriz[prod, seman];
                }

                totalGeral += totalProd[prod];

            }

            //resultado listbox

            lstbxEntrada.Items.Clear();
            for (int prod = 0; prod < 2; prod++)
            {
                for (int seman = 0; seman < 4; seman++)
                {
                    lstbxEntrada.Items.Add($"Total Entradas do Produto {prod + 1}, Semana: {seman + 1} ");
                }
            }

            lstbxEntrada.Items.Add("--------------------------------");

            lstbxEntrada.Items.Add($"Total Geral Entradas: {totalGeral}");

        }
    }   
}
